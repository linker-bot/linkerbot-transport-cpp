"""Failure evidence, process cleanup and report/archive integrity regressions."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import run


def record():
    return dict(name='trial', backend='vcan', fd=False, phase='confirm', requested_seconds=60,
                threads=2, batch=8, window=8, buffer='large', peer=None,
                exit_code=0, timed_out=False,
                result=dict(**{k: 100 for k in ['sent', 'received', 'tx_frames', 'rx_frames', 'peer_received', 'peer_sent']},
                            **{k: 0 for k in ['overflows', 'route_misses', 'invalid_frames', 'inbox_pending']},
                            **{'pass': True}, frames_per_second=100/60, seconds=60,
                            roundtrip_p99_us_upper=99, cpu_percent_one_core=100, rss_final_kib=4096),
                probes=[dict(event=event, role=role, rcvbuf=8388608, drops=0, tune_errno=0, probe_errno=0)
                        for role in ['session', 'peer'] for event in ['open', 'close']],
                rss_samples_kib=dict(min=4096, max=4096, first=4096, last=4096))


class EvidenceTests(unittest.TestCase):
    def test_worker_success_cannot_hide_kernel_loss_or_missing_counter(self):
        good = record()
        self.assertEqual(run.assess(good), [])
        bad = copy.deepcopy(good)
        bad['probes'][1]['drops'] = 1
        self.assertTrue(any('kernel drops' in e for e in run.assess(bad)))
        bad = copy.deepcopy(good)
        bad['probes'].pop()
        self.assertTrue(any('counters missing' in e for e in run.assess(bad)))
        bad = copy.deepcopy(good)
        bad['result']['received'] -= 1
        self.assertIn('Round-trip counts inconsistent', run.assess(bad))

    def test_timeout_exit_and_malformed_json_cannot_be_success(self):
        for field, value in [('timed_out', True), ('exit_code', 1), ('result', None)]:
            r = record()
            r[field] = value
            self.assertTrue(run.assess(r))

    def test_source_dirty_content_and_reverted_commit_detection(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)
            subprocess.run(['git', 'init', '-q', temp], check=True)
            subprocess.run(['git', '-C', temp, 'config', 'user.name', 'test'], check=True)
            subprocess.run(['git', '-C', temp, 'config', 'user.email', 'test@example.invalid'], check=True)
            f = p / 'code.cpp'
            f.write_text('before')
            subprocess.run(['git', '-C', temp, 'add', '.'], check=True)
            subprocess.run(['git', '-C', temp, 'commit', '-qm', 'fixture'], check=True)
            a = run.snapshot(p)
            f.write_text('after')
            self.assertFalse(run.same_source(a, run.snapshot(p)))
            f.write_text('before')
            self.assertTrue(run.same_source(a, run.snapshot(p)))
            (p / 'new.hpp').write_text('new')
            self.assertFalse(run.same_source(a, run.snapshot(p)))

    def test_timeout_kills_descendant_before_it_can_write(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)
            child = 'import time,pathlib;time.sleep(1);pathlib.Path(' + repr(str(p / 'orphan')) + ').touch()'
            parent = 'import subprocess,sys,time;subprocess.Popen([sys.executable,"-c",' + repr(child) + ']);time.sleep(10)'
            _, timed_out = run.execute([sys.executable, '-c', parent], p / 'out', p / 'err', .2)
            self.assertTrue(timed_out)
            time.sleep(1.1)
            self.assertFalse((p / 'orphan').exists())

    def test_report_and_archive_tampering_and_incomplete_results(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            raw, out = root / 'raw', root / 'out'
            raw.mkdir(); out.mkdir()
            meta = dict(quick=False, started_at='start', finished_at='end', source_unchanged=True,
                        errors=['injected failure'], host={})
            run.save(raw / 'metadata.json', meta)
            run.save(raw / 'runs.json', [])
            run.save(raw / 'confirmed.json', {})
            run.publish(raw, out, False, meta, [], {})
            report = (out / 'stress-report.md').read_text()
            self.assertIn('Run incomplete or results invalid', report)
            self.assertNotIn('all four lossless confirmations are valid', report)
            self.assertEqual(run.verify_archive(out / 'stress-raw-data.tar.gz')['confirmed'], 0)
            with self.assertRaisesRegex(RuntimeError, 'Report and raw records inconsistent'):
                run.verify_archive(out / 'stress-raw-data.tar.gz', report + 'tampered')

    def test_missing_dependency_replaces_previous_success_with_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            (out / 'stress-report.md').write_text('old successful report')
            with patch.object(sys, 'argv', ['run.py', '--output', temp]), patch.object(run.shutil, 'which', return_value=None):
                self.assertEqual(run.main(), 1)
            report = (out / 'stress-report.md').read_text()
            self.assertIn('Missing dependency', report)
            self.assertNotIn('old successful', report)
            self.assertNotIn('all four lossless confirmations are valid', report)


if __name__ == '__main__':
    unittest.main()
