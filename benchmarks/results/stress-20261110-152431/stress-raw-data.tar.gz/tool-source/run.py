#!/usr/bin/env python3
"""Build local transport sources and produce an Ubuntu benchmark report + raw archive."""
# English translation of the archived tool snapshot; see localization.json for original hashes.
import argparse
import csv
import datetime as dt
import fcntl
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import tarfile
import tempfile
import time
import threading

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LARGE_BUFFER = 4 * 1024 * 1024
LABELS = {'memory-can': 'Memory loopback Classic CAN', 'memory-fd': 'Memory loopback CAN FD',
          'vcan-can': 'vcan Classic CAN', 'vcan-fd': 'vcan CAN FD'}


def now():
    return dt.datetime.now().astimezone().isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def capture(command, required=True, timeout=30):
    p = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    r = dict(command=command, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr)
    if required and p.returncode:
        raise RuntimeError(f'Command failed: {command}\n{p.stderr}')
    return r


def snapshot(source):
    git = lambda *args: capture(['git', '-C', str(source), *args])['stdout']
    # Include tracked content (also dirty/deleted files), nonignored new files and symlink targets.
    files = git('ls-files', '-z', '--cached', '--others', '--exclude-standard').split('\0')
    manifest = {}
    for name in sorted(set(filter(None, files))):
        p = source / name
        manifest[name] = digest(p) if p.is_file() else ('missing' if not p.exists() else 'directory')
    return dict(path=str(source), commit=git('rev-parse', 'HEAD').strip(),
                status=git('status', '--porcelain=v1', '--untracked-files=all'), files=manifest,
                fingerprint=hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest())


def same_source(a, b):
    return all(a[k] == b[k] for k in ('commit', 'status', 'fingerprint'))


def stop(process, privileged=False):
    if process.poll() is not None:
        return
    for sig in (signal.SIGTERM, signal.SIGKILL):
        if privileged:
            capture(['sudo', '-n', 'kill', f'-{sig.name[3:]}', '--', f'-{process.pid}'], required=False)
        else:
            try:
                os.killpg(process.pid, sig)
            except ProcessLookupError:
                pass
        try:
            process.wait(timeout=5)
            return
        except subprocess.TimeoutExpired:
            continue
    raise RuntimeError('Unable to stop the stress-test process group')


def execute(command, stdout, stderr, timeout, privileged=False):
    """No orphan worker/peer processes on timeout or Python SIGINT/SIGTERM."""
    with Path(stdout).open('w') as out, Path(stderr).open('w') as err:
        p = subprocess.Popen(command, stdout=out, stderr=err, start_new_session=True)
        timed_out = False
        try:
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            stop(p, privileged)
        except BaseException:
            stop(p, privileged)
            raise
    return p.returncode, timed_out


def assess(record):
    """Treat worker exit, full accounting and both kernel socket counters as evidence."""
    r = record.get('result')
    errors = []
    if record['timed_out']:
        errors.append('Timed out')
    if record['exit_code'] != 0:
        errors.append(f"Exit code {record['exit_code']}")
    if not isinstance(r, dict) or r.get('pass') is not True:
        errors.append('Stress validation failed or JSON missing')
    else:
        count = r.get('validated', r.get('received', 0))
        keys = ['tx_frames', 'rx_frames', 'submitted' if 'submitted' in r else 'sent']
        if count <= 0 or any(r.get(k) != count for k in keys):
            errors.append('Round-trip counts inconsistent')
        if record['backend'] == 'vcan' and any(r.get(k) != count for k in ['peer_received', 'peer_sent']):
            errors.append('Peer counts inconsistent')
        if any(r.get(k, -1) != 0 for k in ['overflows', 'route_misses', 'invalid_frames', 'inbox_pending']):
            errors.append('Unexpected library health counters')
        if not all(isinstance(r.get(k), (int, float)) and math.isfinite(r[k]) and r[k] >= 0 for k in
                   ['frames_per_second', 'seconds', 'roundtrip_p99_us_upper', 'cpu_percent_one_core', 'rss_final_kib']):
            errors.append('Missing metrics')
        elif r['seconds'] < record['requested_seconds'] or r['seconds'] <= 0 or not math.isclose(r['frames_per_second'], count/r['seconds'], rel_tol=1e-8):
            errors.append('Duration or throughput calculation inconsistent')
    if record['backend'] == 'vcan':
        probes = record.get('probes', [])
        for role in ['session', 'peer']:
            opened = [x for x in probes if x.get('role') == role and x.get('event') == 'open']
            closed = [x for x in probes if x.get('role') == role and x.get('event') == 'close']
            if len(opened) != 1 or len(closed) != 1:
                errors.append(f'{role} Kernel counters missing')
                continue
            if any(x['probe_errno'] or x['tune_errno'] for x in opened + closed):
                errors.append(f'{role} Kernel counter collection or buffer setup failed')
            if closed[0]['drops'] != opened[0]['drops']:
                errors.append(f"{role} kernel drops {closed[0]['drops'] - opened[0]['drops']}")
            if record['buffer'] == 'large' and opened[0]['rcvbuf'] < LARGE_BUFFER:
                errors.append(f'{role} Insufficient receive buffer')
    return errors


def drops(record, role):
    values = {p['event']: p['drops'] for p in record.get('probes', []) if p['role'] == role}
    return values['close'] - values['open'] if 'close' in values and 'open' in values else None


class Suite:
    def __init__(self, source, raw, quick):
        self.source, self.raw, self.quick = source, raw, quick
        self.build = raw / 'build'
        self.ns = f'lbt-stress-{os.getpid()}'
        self.created = False
        self.watch_stop = threading.Event()
        self.watcher = None
        self.source_changed = False
        self.records, self.confirmed = [], {}
        self.meta = dict(started_at=now(), quick=quick, source_before=snapshot(source), namespace=self.ns,
                         host=dict(uname=platform.uname()._asdict(), os=Path('/etc/os-release').read_text(),
                                   cpu=capture(['lscpu'])['stdout'], compiler=capture(['c++', '--version'])['stdout'],
                                   cpu_affinity=sorted(os.sched_getaffinity(0))),
                         buffer_requested_bytes=LARGE_BUFFER, errors=[])
        self.flush()

    def flush(self):
        save(self.raw / 'runs.json', self.records)
        save(self.raw / 'metadata.json', self.meta)
        save(self.raw / 'confirmed.json', self.confirmed)

    def ns_cmd(self, cmd):
        return ['sudo', '-n', 'ip', 'netns', 'exec', self.ns] + cmd

    def configure(self, cmd, required=True):
        r = capture(cmd, required=required)
        self.meta.setdefault('configuration', []).append(r)
        self.flush()
        return r

    def setup(self):
        print(f'Network namespace for this run: {self.ns}; temporary directory: {self.raw}', flush=True)
        self.configure(['sudo', '-n', 'true'])
        self.meta['interfaces_before'] = capture(['ip', '-j', '-d', 'link', 'show'])
        self.configure(['sudo', '-n', 'modprobe', 'vcan'])
        self.configure(['sudo', '-n', 'ip', 'netns', 'add', self.ns])
        self.created = True
        self.configure(self.ns_cmd(['ip', 'link', 'add', 'vcan0', 'type', 'vcan']))
        self.configure(self.ns_cmd(['ip', 'link', 'set', 'vcan0', 'up']))
        command = ['cmake', '-S', str(HERE), '-B', str(self.build), '-DCMAKE_BUILD_TYPE=Release',
                   f'-DTRANSPORT_SOURCE={self.source}']
        self.meta['build_command'] = command
        for name, cmd in [('configure', command), ('compile', ['cmake', '--build', str(self.build), '-j', str(min(8, os.cpu_count() or 1))])]:
            code, timed_out = execute(cmd, self.raw / f'{name}.stdout', self.raw / f'{name}.stderr', 180)
            if code or timed_out:
                raise RuntimeError(f'{name} build failed or timed out; inspect the raw records')
        library, version, linked_source = (self.build / 'linked-library.txt').read_text().splitlines()
        library = Path(library)
        if linked_source != str(self.source) or not library.resolve().is_relative_to(self.build.resolve()):
            raise RuntimeError('Linked artifact is not from this local source build')
        self.meta['library'] = dict(path=str(library), sha256=digest(library), version=version, source=linked_source)
        for worker in ['throughput', 'profile']:
            link_map = (self.build / f'{worker}_worker.map').read_text()
            linked_paths = [line.split(None, 1)[1] for line in link_map.splitlines() if line.startswith('LOAD ')]
            if not any((self.build / path).resolve() == library.resolve() for path in linked_paths):
                raise RuntimeError(f'{worker} link map does not contain the library from this build')
        commands = json.loads((self.build / 'compile_commands.json').read_text())
        if not any(str(self.source / 'src') in x['file'] for x in commands):
            raise RuntimeError('The selected local source was not compiled')
        self.meta['source_after_build'] = snapshot(self.source)
        if not same_source(self.meta['source_before'], self.meta['source_after_build']):
            raise RuntimeError('Source changed during the build; test invalid')
        code, timed_out = execute([str(self.build / 'throughput_worker'), '--contracts'],
                                  self.raw / 'contracts.json', self.raw / 'contracts.log', 60)
        self.meta['contracts'] = dict(exit_code=code, timed_out=timed_out,
                                     result=json.loads((self.raw / 'contracts.json').read_text()))
        if code or timed_out or not self.meta['contracts']['result'].get('pass'):
            raise RuntimeError('Queue boundary or recovery contract test failed')
        self.flush()
        def watch_source():
            while not self.watch_stop.wait(1):
                try:
                    if not same_source(self.meta['source_before'], snapshot(self.source)):
                        self.source_changed = True
                        self.meta['errors'].append('Source change detected during testing; results invalid even if the change was reverted')
                        return
                except Exception as exc:
                    self.meta['errors'].append(f'Source monitoring error: {exc}')
                    return
        self.watcher = threading.Thread(target=watch_source, daemon=True)
        self.watcher.start()

    def mode(self, fd):
        self.configure(self.ns_cmd(['ip', 'link', 'set', 'vcan0', 'down']))
        self.configure(self.ns_cmd(['ip', 'link', 'set', 'vcan0', 'mtu', '72' if fd else '16']))
        self.configure(self.ns_cmd(['ip', 'link', 'set', 'vcan0', 'up']))

    def run(self, backend, fd, phase, seconds, threads, batch, window, buffer='large', peer=None):
        seconds = min(seconds, 2) if self.quick else seconds
        name = f'{len(self.records):03d}-{phase}-{backend}-{"fd" if fd else "can"}-t{threads}-b{batch}-w{window}'
        worker = 'profile' if peer is not None else 'throughput'
        cmd = [str(self.build / f'{worker}_worker'), '--seconds', str(seconds), '--threads', str(threads),
               '--batch', str(batch), '--window', str(window), '--samples', str(self.raw / f'{name}.csv')]
        if fd:
            cmd.append('--fd')
        if peer is not None and peer:
            cmd += ['--raw-peer', '--peer-batch', str(peer)]
        if backend == 'vcan':
            if peer is None:
                cmd += ['--vcan', 'vcan0']
            env = [f'LD_PRELOAD={self.build / "libsocket_probe.so"}', f'LBT_PROBE_LOG={self.raw / (name + ".jsonl")}']
            if buffer == 'large':
                env += [f'LBT_SESSION_RCVBUF={LARGE_BUFFER}', f'LBT_PEER_RCVBUF={LARGE_BUFFER}']
            cmd = self.ns_cmd(['env', *env, *cmd])
        print(f'START {name} ({seconds}s)', flush=True)
        started = time.monotonic()
        before = capture(self.ns_cmd(['ip', '-j', '-s', 'link', 'show', 'vcan0'])) if backend == 'vcan' else None
        code, timed_out = execute(cmd, self.raw / f'{name}.json', self.raw / f'{name}.log', seconds + 20, backend == 'vcan')
        try:
            result = json.loads((self.raw / f'{name}.json').read_text())
        except (ValueError, OSError):
            result = None
        probe = self.raw / f'{name}.jsonl'
        try:
            probes = [json.loads(line) for line in probe.read_text().splitlines()] if probe.exists() else []
        except ValueError:
            probes = []
        record = dict(name=name, backend=backend, fd=fd, phase=phase, requested_seconds=seconds,
                      threads=threads, batch=batch, window=window, buffer=buffer, peer=peer,
                      command=cmd, exit_code=code, timed_out=timed_out, wall_seconds=time.monotonic()-started,
                      result=result, probes=probes, interface_before=before,
                      interface_after=capture(self.ns_cmd(['ip', '-j', '-s', 'link', 'show', 'vcan0'])) if backend == 'vcan' else None)
        samples = list(csv.DictReader(io.StringIO((self.raw / f'{name}.csv').read_text()))) if (self.raw / f'{name}.csv').exists() else []
        rss = [int(x['rss_kib']) for x in samples]
        record['rss_samples_kib'] = dict(min=min(rss), max=max(rss), first=rss[0], last=rss[-1]) if rss else None
        record['errors'] = assess(record)
        record['pass'] = not record['errors']
        if timed_out or result is None:
            self.meta['errors'].append(f'{name} timed out or valid JSON missing')
        self.records.append(record)
        self.flush()
        print(f"END {name}: " + (f"PASS {result['frames_per_second']:.0f} fps" if record['pass'] else '; '.join(record['errors'])), flush=True)
        return record

    def top(self, backend, fd, phases):
        return sorted([r for r in self.records if r['backend'] == backend and r['fd'] == fd and
                       r['phase'] in phases and r['pass']], key=lambda r: r['result']['frames_per_second'], reverse=True)

    def search(self, backend, fd):
        smoke = self.run(backend, fd, 'smoke', 2, 1, 1, 8)
        if not smoke['pass']:
            raise RuntimeError(f'{backend}/{fd} basic round-trip check failed')
        configs = [(t, b, 8) for b in [1, 8] for t in [1, 2, 4, 8, 16, 32]]
        configs += [(t, b, 1) for b in [32, 128] for t in [1, 8]]
        if self.quick:
            configs = [(1, 8, 8), (8, 128, 1)]
        for t, b, w in configs:
            self.run(backend, fd, 'screen', 15, t, b, w)
        best = self.top(backend, fd, ['screen'])
        if not best:
            raise RuntimeError('No lossless screening candidate')
        best = best[0]
        for w in ([1] if self.quick else [1, 4, 16, 32]):
            if best['threads'] * best['batch'] * w > 4096 or best['threads'] * w > 1024:
                continue
            if any(r['backend'] == backend and r['fd'] == fd and (r['threads'], r['batch'], r['window']) ==
                   (best['threads'], best['batch'], w) for r in self.records):
                continue
            self.run(backend, fd, 'window', 15, best['threads'], best['batch'], w)
        for r in self.top(backend, fd, ['screen', 'window'])[:2]:
            self.run(backend, fd, 'retest', 30, r['threads'], r['batch'], r['window'])
        for candidate in self.top(backend, fd, ['retest'])[:2]:
            trials = []
            for _ in range(2):
                r = self.run(backend, fd, 'confirm', 60, candidate['threads'], candidate['batch'], candidate['window'])
                if not r['pass']:
                    break
                trials.append(r['name'])
            if len(trials) == 2:
                self.confirmed[f'{backend}-{"fd" if fd else "can"}'] = trials
                self.flush()
                return
        raise RuntimeError(f'{backend}/{fd} no configuration passed two consecutive confirmations')

    def diagnostics(self, fd):
        for _ in range(1 if self.quick else 3):
            self.run('vcan', fd, 'overload', 15, 8, 8, 8, 'default', peer=0)
        for phase, t, b, w, buffer, seconds in [('buffer-control', 8, 8, 8, 'large', 30),
                                               ('window-control', 8, 8, 1, 'default', 15)]:
            self.run('vcan', fd, phase, seconds, t, b, w, buffer, peer=0)
        for _ in range(1 if self.quick else 2):
            for t, w in [(2, 8), (8, 2), (8, 8)]:
                self.run('vcan', fd, 'matched', 15, t, 8, w, peer=0)
        if fd:
            # Identical raw peer code paths: change only read/write vs recvmmsg/sendmmsg.
            for peer in [0, 1, 32]:
                self.run('vcan', fd, 'peer-comparison', 60, 2, 8, 8, peer=peer)

    def cleanup(self):
        self.watch_stop.set()
        if self.watcher:
            self.watcher.join(timeout=40)
            if self.watcher.is_alive():
                self.meta["errors"].append("Source monitoring did not stop normally")
        if self.created:
            pids = capture(['sudo', '-n', 'ip', 'netns', 'pids', self.ns], required=False)
            if pids['stdout'].strip():
                capture(['sudo', '-n', 'kill', '-KILL', *pids['stdout'].split()], required=False)
            result = capture(['sudo', '-n', 'ip', 'netns', 'delete', self.ns], required=False)
            self.meta['cleanup'] = result
            if result['exit_code']:
                self.meta['errors'].append('Network namespace cleanup failed')
            self.created = False
        self.meta['source_after'] = snapshot(self.source)
        self.meta['source_unchanged'] = not self.source_changed and same_source(self.meta['source_before'], self.meta['source_after'])
        if not self.meta['source_unchanged']:
            self.meta['errors'].append('Source changed during testing; results invalid')
        self.meta['finished_at'] = now()
        self.meta['interfaces_after'] = capture(['ip', '-j', '-d', 'link', 'show'], required=False)
        self.flush()


def render_report(meta, records, confirmed):
    library = meta.get('library', {})
    formal = not meta.get('quick')
    valid = len(confirmed) == 4 and meta.get('source_unchanged') is True and not meta.get('errors')
    by_name = {r['name']: r for r in records}
    failed = [r for r in records if not r['pass']]
    host = meta.get('host', {})
    cpu = dict(line.split(':', 1) for line in host.get('cpu', '').splitlines() if ':' in line)
    cpu = {key.strip(): value.strip() for key, value in cpu.items()}
    os_release = dict(line.split('=', 1) for line in host.get('os', '').splitlines() if '=' in line)
    os_name = os_release.get('PRETTY_NAME', 'Unknown').strip('"')
    cpu_name = cpu.get('Model name', 'Unknown').replace(' w/ Radeon 780M Graphics', '')
    cores = int(cpu.get('Core(s) per socket', '0')) * int(cpu.get('Socket(s)', '1'))
    threads = cpu.get('CPU(s)', 'Unknown')
    compiler = host.get('compiler', 'Not recorded').splitlines()[0]
    def timestamp(value):
        try:
            return dt.datetime.fromisoformat(value).isoformat(sep=' ', timespec='seconds')
        except (ValueError, TypeError):
            return str(value or 'Not completed')
    status = ('Formal run completed; all four lossless confirmations are valid' if valid and formal else
              'Quick validation completed (not a formal performance result)' if valid else
              'Run incomplete or results invalid')
    source = meta.get('source_before', {})
    title_suffix = '' if formal else ' (Quick Validation; Not a Formal Result)'
    lines = [f"# Transport {library.get('version', 'Unknown Version')} Stress Test Report{title_suffix}", '',
             '## Ubuntu System Stress Test', '', '### Test Information', '',
             '| Item | Details |', '| --- | --- |',
             f"| Test time | {timestamp(meta.get('started_at'))} to {timestamp(meta.get('finished_at'))} |",
             f'| Status | {status}; {len(records)} configurations, {len(failed)} failed; failed configurations are excluded from lossless results |',
             f"| System | {os_name}, Linux {host.get('uname', {}).get('release', 'Unknown')}, {cpu.get('Architecture', 'Unknown')} |",
             f'| CPU | {cpu_name}, {cores} physical cores / {threads} logical CPUs |',
             f'| Build | {compiler}; C++17; Release (`-O3 -DNDEBUG`) |',
             f"| Tested version | Transport {library.get('version', 'Unknown')}, commit `{source.get('commit', 'Unknown')}` |",
             f"| Source state | {'Local changes recorded in metadata.json' if source.get('status') else 'Clean working tree'}; {'unchanged throughout the test' if meta.get('source_unchanged') else 'source consistency not confirmed; results invalid'} |", '',
             'Full environment details, source fingerprints and linked-library checksums are in the [raw data archive](stress-raw-data.tar.gz).', '',
             '### Test Method', '',
             'The selected local source was compiled directly in a fresh temporary directory, without fetching remote changes or using release packages. Memory loopback and vcan in an isolated network namespace were tested with 8-byte Classic CAN frames and 64-byte CAN FD+BRS frames.',
             ('Quick validation uses a reduced scan with 2-second configurations, covering all four paths, candidate retests, two confirmations and all control experiments. All results below are nonformal.' if not formal else
              'The scan used 1/2/4/8/16/32 sender threads, 1/8 frames per batch and an initial window of 8 batches per thread. Additional runs used 1/8 threads, 32/128 frames per batch and a 1-batch window. The fastest candidate was then tested with windows of 1/4/16/32 batches (at most 4096 frames and 1024 batches in flight). Each screening run lasted 15 seconds. The two fastest lossless candidates were retested for 30 seconds, then the better candidate underwent two consecutive 60-second confirmations; the second candidate was tried if confirmation failed.'),
             'Each thread submits the batches within its window, waits for send receipts and all replies in order, then continues. Validation checks IDs, frame flags, lengths, sequence numbers and payload patterns. Throughput is the number of correctly validated replies divided by actual elapsed seconds; one request plus one reply counts as one complete round trip. All 8 Classic CAN bytes carry the sequence number and timestamp; the other 56 FD bytes are also checked individually.',
             'Normal vcan throughput runs requested a 4 MiB receive buffer at both endpoints, changing only the sockets used by this test. Controls covered default-buffer overload at 8 threads x 8 frames x 8 batches, larger buffers, smaller windows, thread counts at equal in-flight limits, and per-frame versus batched peers with the same FD configuration.',
             'P99 is the upper bound of a 10-microsecond histogram bucket (the final bucket uses the actual maximum). CPU 100% means one logical CPU; process CPU includes the stress driver, communication library and simulated peer, with kernel CPU time counted as system time. RSS covers the whole process. Software loopback results do not represent physical CAN bandwidth.', '',
             '### Test Results', '']
    for key, label in LABELS.items():
        trials = [by_name[n] for n in confirmed.get(key, [])]
        if len(trials) != 2 or not all(r['pass'] for r in trials):
            lines.append(f'- **{label}:** Two lossless confirmations were not completed; no formal result is reported.')
            continue
        a = trials[0]
        results = [r['result'] for r in trials]
        f = lambda metric, scale=1, digits=3: ' / '.join(f'{r[metric]/scale:.{digits}f}' for r in results)
        counts = ' / '.join(str(r.get('validated', r.get('received'))) for r in results)
        rss = [r['rss_samples_kib'] for r in trials if r['rss_samples_kib']]
        rss_text = f"{min(x['min'] for x in rss)/1024:.2f}-{max(x['max'] for x in rss)/1024:.2f}" if rss else 'Not recorded'
        kernel = 'Session 0 / 0, peer 0 / 0' if a['backend'] == 'vcan' else 'Not applicable (no kernel sockets)'
        refs = ', '.join(f'`{name}`' for name in confirmed[key])
        lines.append(f"- **{label}:** Two confirmations: **{f('frames_per_second', 1000000, 4)} million complete round trips/s**; "
                     f"{a['threads']} {'thread' if a['threads'] == 1 else 'threads'}, {a['batch']} frames/batch, a {a['window']}-batch window per thread, "
                     f"at most {a['threads']*a['batch']*a['window']} frames in flight. "
                     f"Validated counts: **{counts}**; P99: **{f('roundtrip_p99_us_upper', 1000)} ms**; "
                     f"CPU: **{f('cpu_percent_one_core', 100, 2)} logical CPUs**; RSS sample range: **{rss_text} MiB**; "
                     f"library overflows: **0 / 0**; kernel drops: **{kernel}**. Raw records: {refs}.")
    lines += ['', 'Actual socket receive buffers (kernel-reported values, which may be twice the requested size):', '']
    for key in ['vcan-can', 'vcan-fd']:
        rs = [by_name[n] for n in confirmed.get(key, [])]
        if rs:
            sizes = ['/'.join(f"{p['role']}={p['rcvbuf']} B" for p in r['probes'] if p['event'] == 'open') for r in rs]
            lines.append(f'- {LABELS[key]}: ' + '; '.join(sizes) + '.')
    lines += ['', '### Performance Analysis', '', '#### 1. Frame Loss Under High Concurrency', '']
    for fd, label in [(False, 'Classic CAN'), (True, 'CAN FD')]:
        overloads = [r for r in records if r['fd'] == fd and r['phase'] == 'overload']
        if not overloads:
            lines.append(f'{label}: Overload testing was not completed; evidence is insufficient.')
            continue
        for r in records:
            if r['fd'] != fd or r['phase'] not in ['overload', 'buffer-control', 'window-control']:
                continue
            x = r['result'] or {}
            buffers = ', '.join(f"{p['role']}={p['rcvbuf']} B" for p in r['probes'] if p['event'] == 'open')
            counts = '/'.join(str(x.get(k, '?')) for k in ['submitted', 'tx_frames', 'peer_received', 'peer_sent', 'rx_frames', 'validated'])
            lines.append(f"- {label} `{r['name']}`: {'PASS' if r['pass'] else 'FAIL'}; "
                         f"{r['threads']} x {r['batch']} x {r['window']}, {r['buffer']} buffers ({buffers}); "
                         f"submitted/library TX/peer RX/peer TX/library RX/validated={counts}; "
                         f"kernel drops: Session={drops(r, 'session')}, peer={drops(r, 'peer')}; library overflows={x.get('overflows', '?')}.")
        lost_roles = {role for role in ['session', 'peer'] if any((drops(r, role) or 0) > 0 for r in overloads)}
        controls = [r for r in records if r['fd'] == fd and r['phase'] in ['buffer-control', 'window-control']]
        if lost_roles:
            roles = ', '.join('Session receiver' if role == 'session' else 'simulated peer receiver' for role in sorted(lost_roles))
            explanation = ('Both larger-buffer and smaller-window controls passed, supporting burst receive-queue overload as the explanation.'
                           if len(controls) == 2 and all(r['pass'] for r in controls) else
                           'Some controls failed; other causes cannot be excluded from this evidence alone.')
            overflow = ('No library overflows were observed in these overload runs.'
                        if all((r['result'] or {}).get('overflows') == 0 for r in overloads) else
                        'See the per-configuration counters for library overflows.')
            lines += ['', f'{label}: Kernel counters confirmed socket receive-queue drops at the {roles}. {explanation} {overflow}', '']
        else:
            lines += ['', f'{label}: No default-buffer kernel drops were recorded in this run. The historical receive-queue loss was not reproduced; inspect current logs rather than applying the historical explanation.', '']
    lines += ['#### 2. Performance Bottlenecks', '']
    for fd, label in [(False, 'Classic CAN'), (True, 'CAN FD')]:
        groups = []
        for t, w in [(2, 8), (8, 2), (8, 8)]:
            rs = [r for r in records if r['fd'] == fd and r['phase'] == 'matched' and r['threads'] == t and r['window'] == w and r['pass']]
            if not rs:
                continue
            avg = lambda k: sum(r['result'][k] for r in rs) / len(rs)
            groups.append((t, w, avg('frames_per_second'), avg('roundtrip_p99_us_upper')))
            lines.append(f"- {label}: {t} threads x 8 frames x {w} batches, at most {t*8*w} frames in flight, "
                         f"{len(rs)} valid control runs; mean {avg('frames_per_second')/1000000:.4f} million round trips/s, "
                         f"mean P99 {avg('roundtrip_p99_us_upper')/1000:.3f} ms, CPU {avg('cpu_percent_one_core')/100:.2f} logical CPUs, "
                         f"peer CPU {avg('peer_cpu_percent')/100:.2f} logical CPUs.")
        if len(groups) == 3:
            a, b, c = groups
            lines += ['', f'{label}: At the same 128-frame in-flight limit, increasing threads from 2 to 8 changed throughput by {(b[2]/a[2]-1)*100:+.1f}%. '
                      f'With 8 threads, increasing the limit from 128 to 512 frames changed throughput by {(c[2]/b[2]-1)*100:+.1f}%, '
                      f'while mean P99 increased from {b[3]/1000:.3f} to {c[3]/1000:.3f} ms. Scheduling and run-to-run variation affect these differences; they support only comparisons between the tested configurations.', '']
        else:
            lines.append(f'{label}: Insufficient valid controls to evaluate thread count or in-flight limits.\n')
    peer_runs = [r for r in records if r['phase'] == 'peer-comparison' and r['pass']]
    for r in peer_runs:
        x = r['result']
        peer = 'library peer, per-frame' if r['peer'] == 0 else 'raw socket peer, per-frame' if r['peer'] == 1 else 'raw socket peer, batches of 32 frames'
        lines.append(f"- FD, identical 2 x 8 x 8 configuration with large buffers, {peer}: "
                     f"{x['frames_per_second']/1000000:.4f} million round trips/s, P99 {x['roundtrip_p99_us_upper']/1000:.3f} ms, "
                     f"peer CPU {x['peer_cpu_percent']/100:.2f} logical CPUs (`{r['name']}`).")
    peers = {r['peer']: r for r in peer_runs}
    if 1 in peers and 32 in peers:
        gain = (peers[32]['result']['frames_per_second']/peers[1]['result']['frames_per_second']-1)*100
        conclusion = ('The test peer implementation affects observed throughput.' if abs(gain) >= 5 else
                      'No change greater than 5% was observed; this does not establish the peer as the dominant bottleneck.')
        lines += ['', f'Changing only the raw socket peer from per-frame to batched processing changed throughput by {gain:+.1f}% in this run. {conclusion}']
    else:
        lines += ['', 'Insufficient FD peer controls to evaluate the benefit of batched replies.']
    lines += ['No function-level or lock profiling evidence was collected, so a unique bottleneck cannot be identified. The best result in this finite parameter search is not an absolute throughput limit of the communication library. RSS describes only the observed finite duration and does not prove freedom from long-term leaks.', '',
              '### Failed Configurations and Integrity', '']
    if failed:
        for r in failed:
            lines.append(f"- `{r['name']}`: " + '; '.join(r['errors']) + f". Raw stdout/log: `{r['name']}.json` / `{r['name']}.log`.")
    else:
        lines.append('All configurations executed in this run passed; this applies only to the actual scope covered above.')
    for error in meta.get('errors', []):
        lines.append(f'- Run error: {error}')
    archive = 'quick-validation-raw-data.tar.gz' if not formal else 'stress-raw-data.tar.gz'
    lines += ['', f'Raw data: `{archive}` in the same directory. The archive contains this report, per-configuration JSON/CSV/logs, socket counters, environment records, source fingerprints, tool sources, compiler options and the linked library. The original collection process verified per-file SHA256 checksums before removing temporary files.', '',
              'This English edition translates the report, diagnostic descriptions and the archived tool snapshot. Measurement values, CSV samples, logs, environment metadata and compiled artifacts are unchanged. Original hashes and the translation scope are recorded in `localization.json`; `manifest.json` contains the updated archive checksums. The translated tool snapshot is not byte-identical to the tool used for the original measurement.', '']
    return '\n'.join(lines)


def verify_archive(path, expected_report=None):
    with tarfile.open(path, 'r:gz') as archive:
        members = {m.name: m for m in archive.getmembers() if m.isfile()}
        read = lambda name: archive.extractfile(members[name]).read()
        manifest = json.loads(read('manifest.json'))
        if set(manifest) != set(members) - {'manifest.json'}:
            raise RuntimeError('Archive file list inconsistent')
        for name, sha in manifest.items():
            if hashlib.sha256(read(name)).hexdigest() != sha:
                raise RuntimeError(f'Archive checksum verification failed: {name}')
        meta, runs, confirmed = [json.loads(read(name)) for name in ['metadata.json', 'runs.json', 'confirmed.json']]
        for r in runs:
            if r['result'] is not None and json.loads(read(r['name'] + '.json')) != r['result']:
                raise RuntimeError(f"Raw JSON and summary inconsistent: {r['name']}")
            if r['errors'] != assess(r) or r['pass'] != (not assess(r)):
                raise RuntimeError(f"Validity assessment inconsistent: {r['name']}")
        if meta.get('library'):
            lib_member = 'build/' + str(Path(meta['library']['path']).relative_to(Path(meta['library']['path']).parents[1]))
            if hashlib.sha256(read(lib_member)).hexdigest() != meta['library']['sha256']:
                raise RuntimeError('Linked-library checksum and archive inconsistent')
        for r in runs:
            probe_name = r['name'] + '.jsonl'
            if probe_name in members and [json.loads(x) for x in read(probe_name).decode().splitlines()] != r['probes']:
                raise RuntimeError('Raw socket counters and summary inconsistent')
            csv_name = r['name'] + '.csv'
            if csv_name in members:
                rss = [int(x['rss_kib']) for x in csv.DictReader(io.StringIO(read(csv_name).decode()))]
                expected = dict(min=min(rss), max=max(rss), first=rss[0], last=rss[-1]) if rss else None
                if expected != r['rss_samples_kib']:
                    raise RuntimeError('RSS samples and summary inconsistent')
        for key, names in confirmed.items():
            rs = [r for name in names for r in runs if r['name'] == name]
            if key not in LABELS or len(rs) != 2 or len(set(names)) != 2 or not all(r['pass'] and r['phase'] == 'confirm' and r['requested_seconds'] == (2 if meta['quick'] else 60) for r in rs):
                raise RuntimeError('Confirmation data incomplete')
        report = render_report(meta, runs, confirmed)
        if read('report.md').decode() != report or (expected_report is not None and report != expected_report):
            raise RuntimeError('Report and raw records inconsistent')
    return dict(records=len(runs), confirmed=len(confirmed), source_unchanged=meta.get('source_unchanged'), errors=meta['errors'])


def publish(raw, output, quick, meta, records, confirmed):
    report = render_report(meta, records, confirmed)
    (raw / 'report.md').write_text(report)
    # Include exactly the sources which ran, not __pycache__ or previous results.
    tools = raw / 'tool-source'
    tools.mkdir(exist_ok=True)
    for p in HERE.iterdir():
        if p.is_file() and p.suffix in ['.py', '.cpp', '.c', '.txt', '.md']:
            shutil.copy2(p, tools / p.name)
    manifest = {str(p.relative_to(raw)): digest(p) for p in raw.rglob('*') if p.is_file() and p.name != 'manifest.json'}
    save(raw / 'manifest.json', manifest)
    prefix = 'quick-validation' if quick else 'stress'
    archive_path, report_path = output / f'{prefix}-raw-data.tar.gz', output / f'{prefix}-report.md'
    with tempfile.NamedTemporaryFile(prefix='.stress-archive-', dir=output, delete=False) as tmp:
        pending = Path(tmp.name)
    try:
        with tarfile.open(pending, 'w:gz') as archive:
            for p in sorted(raw.rglob('*')):
                if p.is_file():
                    archive.add(p, arcname=str(p.relative_to(raw)), recursive=False)
        verify_archive(pending, report)
        os.replace(pending, archive_path)
        with tempfile.NamedTemporaryFile(mode='w', prefix='.stress-report-', dir=output, delete=False) as tmp:
            tmp.write(report)
            pending = Path(tmp.name)
        os.replace(pending, report_path)
    finally:
        pending.unlink(missing_ok=True)
    print(f'OUTPUT {report_path}\nOUTPUT {archive_path}\nArchive and report consistency checks passed', flush=True)


def interrupted(signum, frame):
    raise KeyboardInterrupt(f'Received signal {signum}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT / 'linkerbot-transport-cpp', help='Local source directory; no automatic remote synchronization')
    parser.add_argument('--quick', action='store_true', help='Quick validation with 2-second configurations; separate output, not formal results')
    parser.add_argument('--output', type=Path, default=ROOT, help='Output directory for the report and archive')
    parser.add_argument('--verify', type=Path, help='Verify an existing raw data archive and report metrics only')
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify_archive(args.verify), ensure_ascii=False))
        return 0
    source, output = args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    # Serialize runs without leaving a lock file in the workspace.
    lock_path = Path(tempfile.gettempdir()) / ('lbt-stress-' + hashlib.sha256(str(output).encode()).hexdigest()[:16] + '.lock')
    with lock_path.open('w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('A stress test is already using this output directory', flush=True)
            return 1
        signal.signal(signal.SIGINT, interrupted)
        signal.signal(signal.SIGTERM, interrupted)
        with tempfile.TemporaryDirectory(prefix='lbt-stress-') as temp:
            raw = Path(temp)
            suite = None
            meta = dict(started_at=now(), quick=args.quick, errors=[])
            try:
                for tool in ['cmake', 'c++', 'cc', 'git', 'ip', 'sudo', 'modprobe']:
                    if not shutil.which(tool):
                        raise RuntimeError(f'Missing dependency: {tool}')
                if platform.system() != 'Linux' or 'Ubuntu' not in Path('/etc/os-release').read_text():
                    raise RuntimeError('This tool supports Ubuntu Linux only')
                if not (source / 'CMakeLists.txt').is_file():
                    raise RuntimeError(f'Local source not found: {source}')
                suite = Suite(source, raw, args.quick)
                suite.setup()
                for fd in [False, True]:
                    suite.mode(fd)
                    for backend in ['memory', 'vcan']:
                        suite.search(backend, fd)
                    suite.diagnostics(fd)
            except BaseException as exc:
                meta = suite.meta if suite else meta
                meta['errors'].append(f'{type(exc).__name__}: {exc}')
                print(f'FAILED {exc}', flush=True)
            finally:
                if suite:
                    try:
                        suite.cleanup()
                    except BaseException as exc:
                        suite.meta['errors'].append(f'Cleanup or source verification failed: {exc}')
                    meta, records, confirmed = suite.meta, suite.records, suite.confirmed
                else:
                    records, confirmed = [], {}
                    meta['finished_at'] = now()
                save(raw / 'metadata.json', meta)
                save(raw / 'runs.json', records)
                save(raw / 'confirmed.json', confirmed)
                publish(raw, output, args.quick, meta, records, confirmed)
            valid = len(confirmed) == 4 and meta.get('source_unchanged') and not meta['errors']
            return 0 if valid else 1


if __name__ == '__main__':
    raise SystemExit(main())
