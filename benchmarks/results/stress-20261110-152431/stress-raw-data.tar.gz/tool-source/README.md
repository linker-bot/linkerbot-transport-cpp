# Local Transport Stress Test on Ubuntu

This is an English translation of the historical tool snapshot used for the 2026-11-10 measurements. The original measurement paths and library hashes remain in metadata.json. The translated snapshot is not byte-identical to the original tool; localization.json records the original hashes. CSV samples, numeric measurements and compiled artifacts are unchanged.

## Verify This English Archive

The English report and diagnostic strings use the bundled English verifier. The current repository verifier generates Chinese reports and is not the verifier for this localized archive. From the directory containing stress-raw-data.tar.gz:

```sh
archive_path="$PWD/stress-raw-data.tar.gz"
verify_dir=$(mktemp -d)
tar -xzf "$archive_path" -C "$verify_dir" tool-source/run.py
PYTHONDONTWRITEBYTECODE=1 python3 "$verify_dir/tool-source/run.py" --verify "$archive_path"
rm -r -- "$verify_dir"
```

Verification checks every manifest SHA256, all per-configuration JSON records, validity assessments, socket counters, RSS summaries, the linked library, both confirmations for each scenario, and report regeneration. No hardware channel is opened.

## Historical Collection Method

The original tool tested the adjacent linkerbot-transport-cpp Git working tree directly, without remote synchronization or release packages. It required Ubuntu, Python 3.10+, CMake, GCC/G++, Git, iproute2, kmod, vcan kernel support, and noninteractive sudo permission for ip netns, modprobe vcan and kill. No physical CAN adapter was required.

Each run built Release artifacts in a fresh temporary directory and linked linkerbot::can. The library's tests, examples, benchmarks, serial/Modbus and dependency downloads were disabled. The archive records the version, HEAD, working-tree state, source SHA256 manifest, compiler commands, link maps and actual library checksums. Source fingerprints were checked after building, during testing and after testing; changes invalidated the result. Local changes were allowed only when explicitly recorded.

Formal scans covered memory/vcan x 8-byte Classic CAN/64-byte FD+BRS, 1/2/4/8/16/32 threads, 1/8 frames per batch and 8 batches per thread. Additional scans used 1/8 threads, 32/128 frames per batch and a 1-batch window, then candidate windows of 1/4/16/32 batches. Screening lasted 15 seconds per configuration; the two fastest lossless candidates received 30-second retests, followed by two consecutive 60-second confirmations. Failed configurations were listed separately and excluded from lossless results.

Normal vcan runs requested 4 MiB receive buffers at both endpoints and recorded actual sizes and kernel drops. Controls covered queue boundaries and recovery, default-buffer overload, larger buffers, smaller windows, thread counts at equal in-flight limits, and FD peers with per-frame versus batched replies.

throughput_worker.cpp implements throughput and per-frame validation. profile_worker.cpp implements queue, CPU and peer comparisons. socket_probe.c collects kernel socket statistics on open/close and changes only the test sockets' receive buffers; it does not intercept frame reads or writes. run.py orchestrates collection, cleanup and report generation. CPU and RSS include the simulated peer. Software loopback results do not represent physical CAN bandwidth.

The English snapshot uses stress-report.md and stress-raw-data.tar.gz for formal output, and quick-validation-report.md and quick-validation-raw-data.tar.gz for quick validation. Build artifacts, per-configuration JSON/CSV/logs, actual linked libraries and compiler records are archived before temporary directories are removed. Historical temporary paths need not exist after cleanup.

Only a dedicated network namespace and vcan interface were created. Physical interfaces and global sysctl settings were not changed. Normal completion, errors, timeouts and SIGINT/SIGTERM stop the run's process groups, clean up the namespace and archive existing evidence. Failures return nonzero and mark the report incomplete. SIGKILL and power loss cannot be caught. Archive verification failures are never reported as success.

The archived test_run.py contains the original regression tests with English assertions. Historical Raspberry Pi tools are separate from this Ubuntu workflow. Earlier Ubuntu tooling was archived before migration as archives/stress-tools-before-migration-20261110.tar.gz.
